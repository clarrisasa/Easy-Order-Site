<?php
    $cek = mysqli_connect("localhost", "root", "", "mahasiswa");
    if ($cek)
        echo "Alhamdulillah diterima";

?>