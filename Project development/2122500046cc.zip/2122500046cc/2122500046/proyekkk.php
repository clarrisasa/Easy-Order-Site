<html>
  <head>
    <title>PARADISE CAFE</title>
    <!-- Bootstrap -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link href="assets/stylenew.css" rel="stylesheet">
  </head>
  <body>

  <!--happy code-->

  <!-- jQuery lokal -->
  <script src="assets/jquery/jquery.min.js"></script>
 
 <script src="assets/bootstrap/js/bootstrap.min.js"></script>
 
 <!-- Custom JS -->
 <script src="assets/custom.js"></script>
 <div class="container">

 <!-- Bagian Header -->
 <div class="row">
        <div class="col-md-12 header" id="site-header">
            <!-- isi header -->
			<header align="center">
			<p> </p>
        <img src="cafee.jpg" width="1000px" height="500px"align="center">
            <header align="center">
    <nav class="menus">
    <ul align="center">
        <li><a href="login_proyek.php">LOGIN</a></li>
		<li><a href="porto.html">MENU MAKANAN</a></li>
		<li><a href="galeri.html">MENU MINUMAN</a></li>
		<li><a href="about.us.html">TENTANG KAMI</a></li>
    </ul>
</nav>
    </header>
    </div>
    </div>   
	</header>
    <!-- End Bagian Header -->

