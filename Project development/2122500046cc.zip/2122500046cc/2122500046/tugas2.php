<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
$n = 1;
for($i=0; $i<=4; $i++)
{
    $n = $n + $i;
    echo "$n ";
}
    
?>
</body>
</html>