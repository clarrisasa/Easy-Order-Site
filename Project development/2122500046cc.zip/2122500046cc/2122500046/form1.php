<html>
    <title>
        www.cecewebsite
    </title>
<body>
    <form action= "welcome.php" method="post">
    <h2><p style="text-align:center">INPUT YOUR NAME AND AGE!! </p></h2>
    <p style="text-align:center"> Enter Your Name : <input type = "text" name = "name"> </p> 
    <p style="text-align:center"> Enter Your Age &nbsp : <input type = "text" name = "age"> </p> 
    <p style="text-align:center"> <input type = "submit" name = "submit" value = "kirim"> </p> <br>
    </form> 
</body>
</html>