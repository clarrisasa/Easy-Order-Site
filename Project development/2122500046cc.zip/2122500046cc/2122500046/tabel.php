<html>
    <head>
        <title>
            form
        </title>
    </head>
    <body>
        <h3> DATA MAHASISWA ELEKTRONIKA </h3>
    <table width="25%" border="1">
    <tr> 
                <td> $d->nrp </td>
                <td> $d->nama </td>
                <td> $d->hp </td>
            </tr>
</table>

    </body>
</html>