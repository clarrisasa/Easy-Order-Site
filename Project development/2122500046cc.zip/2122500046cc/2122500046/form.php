<html>
    <head>
        <title>
            form
        </title>
    </head>
    <body>
    <!-- karena ingin mambuat form, maka janganlupa <form action>, kalau dalam action terdapat file yang di ketik an berarti akan 
        mengarah kesana ketika disend, tapi kali ini membuat form untuk mengarah pada dirinya sendiri.
    Method adalah metode yang digunakan ada POST dan GET nah nanti dijelaskan dalam laporan ya!-->
    <form action="" method="GET">
        nama <input type ="text" name="nama" value=""> <br> <br> 
        email <input type ="text" name="email" value=""> <br> <br> 
        subjek <input type ="text" name="subjek" value=""> <br> <br>
        message <input type ="text" name="message" value=""> <br> <br>
        <input type ="submit" name="send" value="send">
    </form>
<?php
    if(isset($_GET['send']))
        echo "$_GET[nama] <br> $_GET[email] <br> $_GET[subjek] <br> $_GET[message]";
?>
    </body>
</html>