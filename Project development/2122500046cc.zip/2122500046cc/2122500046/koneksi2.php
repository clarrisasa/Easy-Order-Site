<?php
    $cek = mysqli_connect("localhost", "root", "", "mahasiswa");
    if ($cek)
       // echo "Siswa Elektronika <br>";
        

?>