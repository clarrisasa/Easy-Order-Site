<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
for($i=1; $i<=5; $i++)
{
    $hsl = $i*$i;
    echo "$hsl ";
}
    
?>
</body>
</html>