<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
    $a=11;
    $b=22;
    $c = $a + $b;
    echo "$a + $b = $c"
?>
</body>
</html>