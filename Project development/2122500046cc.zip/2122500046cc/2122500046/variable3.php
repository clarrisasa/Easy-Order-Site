<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
    $a=11;
    $b=22;
    $c = $a + $b;
    for($i=1; $i<=10; $i++)
    echo "$i + $b = $c <br>"
?>
</body>
</html>