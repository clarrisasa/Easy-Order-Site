<html>
    <title>
        www.cecewebsite
    </title>
<body>
  welcome <br><?php echo $_POST ["name"];?><br>
  you are <?php echo $_POST ["age"];?> years old!
</body>
</html>