<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
for($i=1; $i<=10; $i++)
echo "$i <br>"
?>
</body>
</html>