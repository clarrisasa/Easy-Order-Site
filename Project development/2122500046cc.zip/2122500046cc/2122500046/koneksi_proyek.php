<?php
    $cek = mysqli_connect("localhost", "root", "", "proyek");
    if ($cek)
        echo "Booked Complate";

?>