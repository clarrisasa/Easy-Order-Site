<html>
    <title>
        www.cecewebsite
    </title>
<body>
<form action="" method="POST">
        nilai1 <input type ="text" name="nilai1" value=""> <br> <br> 
        nilai2 <input type ="text" name="nilai2" value=""> <br> <br>
        <input type="submit" name="send">
</body>
</html>