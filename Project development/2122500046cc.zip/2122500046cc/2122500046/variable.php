<html>
<head>
    <title>
        clarrisa website
    </title>
</head>
<body>
    <?php
    $a=1;
    $b=2;
    echo "$a $b"
?>
</body>
</html>