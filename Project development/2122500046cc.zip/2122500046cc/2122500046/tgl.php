<html>
<head>
    <title>
        wwww.ceceweb
    </title>
</head>
<body>
    <?php
    echo "EB<br>". date ("Y-M-H : i : s");
    date_default_timezone_set ("Asia/Jakarta");
?>
</body>
</html>